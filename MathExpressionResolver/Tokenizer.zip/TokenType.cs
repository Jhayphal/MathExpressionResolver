﻿namespace MathExpressionResolver
{
    internal enum TokenType
    {
        Number,
        Operator,
        OpenBracket,
        CloseBracket
    }
}
